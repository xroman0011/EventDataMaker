﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventDataMaker
{
    public class WeekData
    {
        public string Dia { get; set; }
        public string Telefono { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Collaborate { get; set; } = string.Empty;
        public string Presencial { get; set; } = string.Empty;
    }
}
