<?php

?>

<!DOCTYPE html>
<style>
    table, th, td {
        border: 1px solid black;
    }

</style>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Event Data Maker</title>
</head>
<body>
    <table style="width:100%">
        <tr>
            <th>AREA DE ENFASIS CAI</th>
            <th>Logros del mes</th>
            <th>Acumulado</th>
        </tr>
        <tr>
            <td>DESAROLLO Y ACTUALIZACION DE LAS COLECCIONES</td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td><ul><li>Assessment de las colecciones</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Prontuarios cotejados</td>
            <td><center><input type="number" id="input1" name="proLDM"></center></td>
            <td><center><input type="number" id="input2" name="roAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Participacion de la comunidad academia-(total de recomendaciones)</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Facultad</td>
            <td><center><input type="number" id="input3" name="facLDM"></center></td>
            <td><center><input type="number" id="input4" name="facAcu"></center></td>
        </tr>
        <tr>
            <td>_Administracion</td>
            <td><center><input type="number" id="input5" name="admLDM"></center></td>
            <td><center><input type="number" id="input6" name="admAcu"></center></td>
        </tr>
        <tr>
            <td>_Estudiantes</td>
            <td><center><input type="number" id="input7" name="estLDM"></center></td>
            <td><center><input type="number" id="input8" name="estAcu"></center></td>
        </tr>
        <tr>
            <td>_Comunidad</td>
            <td><center><input type="number" id="input9" name="estLDMCom"></center></td>
            <td><center><input type="number" id="input10" name="estAcuCom"></center></td>
        </tr>
        <tr>
            <td><ul><li>Adquisiciones/Recursos nuevos (A+B)</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Titulos</td>
            <td><center><input type="number" id="input11" name="titLDM"></center></td>
            <td><center><input type="number" id="input12" name="titAcu"></center></td>
        </tr>
        <tr>
            <td>_Volumenes</td>
            <td><center><input type="number" id="input13" name="volLDM"></center></td>
            <td><center><input type="number" id="input14" name="volAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>A.Compras</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Titulos</td>
            <td><center><input type="number" id="input15" name="AtitLDM"></center></td>
            <td><center><input type="number" id="input16" name="AtitAcu"></center></td>
        </tr>
        <tr>
            <td>_Volumenes</td>
            <td><center><input type="number" id="input17" name="AvolLDM"></center></td>
            <td><center><input type="number" id="input18" name="AvolAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>B.Donaciones</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Titulos</td>
            <td><center><input type="number" id="input19" name="BtitLDM"></center></td>
            <td><center><input type="number" id="input20" name="BtitAcu"></center></td>
        </tr>
        <tr>
            <td>_Volumenes</td>
            <td><center><input type="number" id="input21" name="BvolLDM"></center></td>
            <td><center><input type="number" id="input22" name="BvolAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Crecimiento de las colecciones (catologados)</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Titulos</td>
            <td><center><input type="number" id="input23" name="titLDM2"></center></td>
            <td><center><input type="number" id="input24" name="titAcu2"></center></td>
        </tr>
        <tr>
            <td>_Volumenes</td>
            <td><center><input type="number" id="input25" name="volLDM2"></center></td>
            <td><center><input type="number" id="input26" name="volAcu2"></center></td>
        </tr>
        <tr>
            <td><ul><li>Mantenimiento de las colecciones</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td><ul><li>Encuadernaciones (volumenes procesados)</li></ul></td>
            <td></td>
            <td><center><input type="number" id="input27" name="volAcuPro"></center></td>
        </tr>
        <tr>
            <td><ul><li>Descarte</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Titulos</td>
            <td><center><input type="number" id="input28" name="DesTitLDM"></center></td>
            <td><center><input type="number" id="input29" name="DesTitAcu"></center></td>
        </tr>
        <tr>
            <td>_Volumenes</td>
            <td><center><input type="number" id="input30" name="DesvolLDM"></center></td>
            <td><center><input type="number" id="input31" name="DesvolAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Otros</li></ul></td>
            <td><center><input type="number" id="input32" name="OtrosLDM"></center></td>
            <td><center><input type="number" id="input33" name="OtrosAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Recursos virtuales de informacion</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Adquiridos</td>
            <td><center><input type="number" id="input34" name="adqLDM"></center></td>
            <td><center><input type="number" id="input35" name="adqAcu"></center></td>
        </tr>
        <tr>
            <td>_Evaluados para compra</td>
            <td><center><input type="number" id="input36" name="EvaLDM"></center></td>
            <td><center><input type="number" id="input37" name="EvalAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Acceso a la informacion</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Pagina de Web</td>
            <td><center><input type="number" id="input38" name="pagLDM"></center></td>
            <td><center><input type="number" id="input39" name="pagAcu"></center></td>
        </tr>
        <tr>
            <td>_Indizacion</td>
            <td><center><input type="number" id="input40" name="indLDM"></center></td>
            <td><center><input type="number" id="input41" name="indAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Recursos Audiovisuales</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Digitalizados</td>
            <td><center><input type="number" id="input42" name="DigLDM"></center></td>
            <td><center><input type="number" id="input43" name="DigAcu"></center></td>
        </tr>
        <tr>
            <td>_Reparados</td>
            <td><center><input type="number" id="input44" name="repLDM"></center></td>
            <td><center><input type="number" id="input45" name="repAcu"></center></td>
        </tr>
        <tr>
            <td>_Producidos</td>
            <td><center><input type="number" id="input46" name="proLDM2"></center></td>
            <td><center><input type="number" id="input47" name="proAcu2"></center></td>
        </tr>
        <tr>
            <th>DESTREZAS PARA EL MANEJO DE LA INFORMACION</th>
            <th></th>
            <th></th>
        </tr>
        <tr>
            <td><ul><li>Talleres: Estudiantes</li></ul></td>
            <td><center><input type="number" id="input48" name="TallEstAcu"></center></td>
            <td><center><input type="number" id="input49" name="TallFacAcu"></center></td>
        </tr>
        <tr>
            <td>_Participantes</td>
            <td><center><input type="number" id="input50" name="parEstLDM"></center></td>
            <td><center><input type="number" id="input51" name="parEstAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Talleres: Facultad</li></ul></td>
            <td><center><input type="number" id="input52" name="TallFacLDM"></center></td>
            <td><center><input type="number" id="input53" name="TallFacAcu2"></center></td>
        </tr>
        <tr>
            <td>_Participantes</td>
            <td><center><input type="number" id="input54" name="proFacLDM"></center></td>
            <td><center><input type="number" id="input55" name="proFacAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Talleres: Adminstracion</li></ul></td>
            <td><center><input type="number" id="input56" name="TallAdmLDM"></center></td>
            <td><center><input type="number" id="input57" name="TallAdmAcu"></center></td>
        </tr>
        <tr>
            <td>_Participantes</td>
            <td><center><input type="number" id="input58" name="proAdmLDM"></center></td>
            <td><center><input type="number" id="input59" name="proAdmAcu"></center></td>
        </tr>
        <tr>
            <th>USO DE LOS RECURSOS Y FACILIDADES</th>
            <th></th>
            <th></th>
        </tr>
        <tr>
            <td><ul><li>Uso de los recursos*</li></ul></td>
            <td><center><input type="number" id="input60" name="usoLDM"></center></td>
            <td><center><input type="number" id="input61" name="usoAcu"></center></td>
        </tr>
        <tr>
            <td>_Estudiantes</td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Facultad</td>
            <td><center><input type="number" id="input62" name="usoFacLDM"></center></td>
            <td><center><input type="number" id="input63" name="usoFacAcu"></center></td>
        </tr>
        <tr>
            <td>_Administracion</td>
            <td><center><input type="number" id="input64" name="usoAdmLDM"></center></td>
            <td><center><input type="number" id="input65" name="usoAdmAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Uso de las Facilidades</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Salas de Estudio Grupal (3 salas)</td>
            <td><center><input type="number" id="input66" name="segLDM"></center></td>
            <td><center><input type="number" id="input67" name="segAcu"></center></td>
        </tr>
        <tr>
            <td>_Salas de Proyecciones</td>
            <td><center><input type="number" id="input68" name="spLDM"></center></td>
            <td><center><input type="number" id="input69" name="spAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Prestamos Inter Bibliotecarios (Total)</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Prestados</td>
            <td><center><input type="number" id="input70" name="preLDM"></center></td>
            <td><center><input type="number" id="input71" name="preAcu"></center></td>
        </tr>
        <tr>
            <td>_Solicitados</td>
            <td><center><input type="number" id="input72" name="solLDM"></center></td>
            <td><center><input type="number" id="input73" name="solAcu"></center></td>
        </tr>
        <tr>
            <th>OTROS ASPECTOS DEL SERVICIOS</th>
            <th></th>
            <th></th>
        </tr>
        <tr>
            <td><ul><li>Horario</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Asistencia</td>
            <td><center><input type="number" id="input74" name="asiLDM"></center></td>
            <td><center><input type="number" id="input75" name="asiAcu"></center></td>
        </tr>
        <tr>
            <td>_Horas de servicios</td>
            <td><center><input type="number" id="input76" name="horLDM"></center></td>
            <td><center><input type="number" id="input77" name="horAcu"></center></td>
        </tr>
        <tr>
            <td>_Promedio asistencia por hr.</td>
            <td><center><input type="number" id="input78" name="prohrLDM"></center></td>
            <td><center><input type="number" id="input79" name="prohrAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Actividades</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Exposiciones</td>
            <td><center><input type="number" id="input80" name="expLDM"></center></td>
            <td><center><input type="number" id="input81" name="expAcu"></center></td>
        </tr>
        <tr>
            <td>_Exhibiciones</td>
            <td><center><input type="number" id="input82" name="exhLDM"></center></td>
            <td><center><input type="number" id="input83" name="exhAcu"></center></td>
        </tr>
        <tr>
            <td>_Otras</td>
            <td><center><input type="number" id="input84" name="otrLDM"></center></td>
            <td><center><input type="number" id="input85" name="otrAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Promocion de Resursos y servicios</li></ul></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>_Publicaciones nuevas</td>
            <td><center><input type="number" id="input86" name="pubNueLDM"></center></td>
            <td><center><input type="number" id="input87" name="pubNueAcu"></center></td>
        </tr>
        <tr>
            <td>_Publicaciones distribuidas</td>
            <td><center><input type="number" id="input88" name="pubDisLDM"></center></td>
            <td><center><input type="number" id="input89" name="pubDisAcu"></center></td>
        </tr>
        <tr>
            <th>USO DE LOS RECURSOS Y SERVICIOS</th>
            <th></th>
            <th></th>
        </tr>
        <tr>
            <td><ul><li>Prestamos a la comunidad externa</li></ul></td>
            <td><center><input type="number" id="input90" name="prestamosLDM"></center></td>
            <td><center><input type="number" id="input91" name="prestamosAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Talleres y conferencias</li></ul></td>
            <td><center><input type="number" id="input92" name="TallConfLDM"></center></td>
            <td><center><input type="number" id="input93" name="TallConfAcu"></center></td>
        </tr>
        <tr>
            <td>_Talleres ofrecidos</td>
            <td><center><input type="number" id="input94" name="ofrecidosLDM"></center></td>
            <td><center><input type="number" id="input95" name="ofrecidosAcu"></center></td>
        </tr>
        <tr>
            <th>GERENCIA Y PLANTA FISICA:</th>
            <th></th>
            <th></th>
        </tr>
        <tr>
            <td><ul><li>Desarollo de personal (talleres, seminarios, cursos, etc.)</li></ul></td>
            <td><center><input type="number" id="input96" name="desaLDM"></center></td>
            <td><center><input type="number" id="input97" name="desaAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Equipo</li></ul></td>
            <td><center><input type="number" id="input98" name="equiLDM"></center></td>
            <td><center><input type="number" id="input99" name="equiConf"></center></td>
        </tr>
        <tr>
            <td>_Anadido (comprado o donado)</td>
            <td><center><input type="number" id="input100" name="anaLDM"></center></td>
            <td><center><input type="number" id="input101" name="anaAcu"></center></td>
        </tr>
        <tr>
            <td>_Decomisado**</td>
            <td><center><input type="number" id="input102" name="decLDM"></center></td>
            <td><center><input type="number" id="input103" name="decAcu"></center></td>
        </tr>
        <tr>
            <td><ul><li>Planta Fisica</li></ul></td>
            <td></td>
            <td></td>
        </tr>
    </table>
    <input class="btn btn-primary" type="submit" value="Submit">
</body>
</html>